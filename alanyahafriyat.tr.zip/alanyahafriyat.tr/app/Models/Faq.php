<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

class Faq extends Model
{
    protected static string $table = 'faqs';
}
